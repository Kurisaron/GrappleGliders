WASD - movement
Space - jump
left click - grapple to object at center of screen
Hold C - activate glider